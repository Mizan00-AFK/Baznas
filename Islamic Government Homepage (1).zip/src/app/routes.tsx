import { createBrowserRouter } from 'react-router';
import { RootLayout } from './layouts/RootLayout';
import { HomePage } from './pages/HomePage';
import { FormulirBayarZIS } from './pages/FormulirBayarZIS';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: RootLayout,
    children: [
      {
        index: true,
        Component: HomePage,
      },
      {
        path: 'layanan/bayar-zis/formulir',
        Component: FormulirBayarZIS,
      },
    ],
  },
]);

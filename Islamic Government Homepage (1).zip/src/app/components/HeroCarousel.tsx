import {
  useState,
  useEffect,
  useCallback,
  useRef,
} from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import beritaswipe1 from "@/imports/beritaswipe1.jpg";
import beritaswipe2 from "@/imports/beritaswipe2.jpeg";
import beritaswipe3 from "@/imports/beritaswipe3.png";
import beritaswipe4 from "@/imports/beritaswipe4.png";
import beritaswipe5 from "@/imports/beritaswipe5.jpeg";

const SLIDES = [
  {
    id: 1,
    image: beritaswipe1,
    tag: "Program",
    title:
      "BAZNAS Salurkan Bantuan kepada 10.000 Mustahik di Seluruh Indonesia",
    desc: "Program pendistribusian zakat nasional menjangkau jutaan penerima manfaat di berbagai pelosok nusantara.",
    date: "19 Mei 2026",
  },
  {
    id: 2,
    image: beritaswipe2,
    tag: "Beasiswa",
    title:
      "BAZNAS Luncurkan Program Beasiswa untuk 5.000 Pelajar Kurang Mampu",
    desc: "Investasi pendidikan terbaik untuk generasi penerus bangsa melalui program beasiswa BAZNAS.",
    date: "17 Mei 2026",
  },
  {
    id: 3,
    image: beritaswipe3,
    tag: "Pengumuman",
    title:
      "BAZNAS Raih Penghargaan Lembaga Zakat Terbaik Tingkat Nasional 2026",
    desc: "Penghargaan ini merupakan bentuk kepercayaan masyarakat terhadap pengelolaan zakat yang transparan dan akuntabel.",
    date: "15 Mei 2026",
  },
  {
    id: 4,
    image: beritaswipe4,
    tag: "Kegiatan",
    title:
      "BAZNAS Gelar Program Literasi Zakat untuk Masyarakat di Berbagai Daerah",
    desc: "Program edukasi ini mendorong pemahaman zakat yang lebih luas agar manfaatnya semakin tepat sasaran.",
    date: "13 Mei 2026",
  },
  {
    id: 5,
    image: beritaswipe5,
    tag: "Kerja Sama",
    title:
      "BAZNAS Perkuat Kolaborasi dengan Mitra Strategis untuk Dampak yang Lebih Luas",
    desc: "Sinergi lintas lembaga menjadi langkah penting untuk memperluas jangkauan bantuan dan pemberdayaan.",
    date: "11 Mei 2026",
  },
];

export function HeroCarousel() {
  const [current, setCurrent] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const dragStartX = useRef<number | null>(null);
  const dragCurrentX = useRef<number | null>(null);

  const goTo = useCallback(
    (idx: number) => {
      if (isAnimating) return;
      setIsAnimating(true);
      setCurrent(idx);
      setTimeout(() => setIsAnimating(false), 500);
    },
    [isAnimating],
  );

  const prev = useCallback(
    () => goTo((current - 1 + SLIDES.length) % SLIDES.length),
    [current, goTo],
  );
  const next = useCallback(
    () => goTo((current + 1) % SLIDES.length),
    [current, goTo],
  );

  const handlePointerDown = (
    event: React.PointerEvent<HTMLDivElement>,
  ) => {
    dragStartX.current = event.clientX;
    dragCurrentX.current = event.clientX;
    setIsDragging(true);
    event.currentTarget.setPointerCapture(event.pointerId);
  };

  const handlePointerMove = (
    event: React.PointerEvent<HTMLDivElement>,
  ) => {
    if (!isDragging || dragStartX.current === null) return;
    dragCurrentX.current = event.clientX;
  };

  const finishDrag = useCallback(() => {
    if (
      !isDragging ||
      dragStartX.current === null ||
      dragCurrentX.current === null
    ) {
      setIsDragging(false);
      dragStartX.current = null;
      dragCurrentX.current = null;
      return;
    }

    const deltaX = dragCurrentX.current - dragStartX.current;
    const threshold = 60;

    if (deltaX > threshold) {
      prev();
    } else if (deltaX < -threshold) {
      next();
    }

    setIsDragging(false);
    dragStartX.current = null;
    dragCurrentX.current = null;
  }, [isDragging, next, prev]);

  const handlePointerUp = () => {
    finishDrag();
  };

  const handlePointerLeave = () => {
    finishDrag();
  };

  useEffect(() => {
    const timer = setInterval(next, 5000);
    return () => clearInterval(timer);
  }, [next]);

  return (
    <div
      className={`relative w-full overflow-hidden bg-[#eef2ec] ${isDragging ? "cursor-grabbing" : "cursor-grab"}`}
      style={{
        height: "480px",
        touchAction: "none",
        userSelect: "none",
      }}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerLeave={handlePointerLeave}
      onPointerCancel={handlePointerUp}
    >
      {SLIDES.map((s, i) => (
        <div
          key={s.id}
          className={`absolute inset-0 flex items-center justify-center transition-opacity duration-700 ${i === current ? "opacity-100 z-10" : "opacity-0 z-0"}`}
        >
          <ImageWithFallback
            src={s.image}
            alt={s.title}
            draggable={false}
            className="w-full h-full object-contain"
          />
        </div>
      ))}

      <button
        onClick={prev}
        onPointerDown={(event) => event.stopPropagation()}
        aria-label="Sebelumnya"
        className="absolute left-4 top-1/2 -translate-y-1/2 z-20 rounded-full bg-white/85 text-gray-700 shadow-md backdrop-blur-sm transition hover:bg-white"
      >
        <span className="flex h-11 w-11 items-center justify-center">
          <ChevronLeft size={22} />
        </span>
      </button>

      <button
        onClick={next}
        onPointerDown={(event) => event.stopPropagation()}
        aria-label="Berikutnya"
        className="absolute right-4 top-1/2 -translate-y-1/2 z-20 rounded-full bg-white/85 text-gray-700 shadow-md backdrop-blur-sm transition hover:bg-white"
      >
        <span className="flex h-11 w-11 items-center justify-center">
          <ChevronRight size={22} />
        </span>
      </button>
    </div>
  );
}
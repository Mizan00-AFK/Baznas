import { Link } from "react-router";
import {
  ArrowRight,
  FileText,
  CreditCard,
  Store,
} from "lucide-react";

const SHORTCUTS = [
  {
    icon: FileText,
    label: "Formulir",
    desc: "Isi formulir zakat secara online",
    href: "/layanan/bayar-zis/formulir",
    eyebrow: "Primary action",
  },
  {
    icon: CreditCard,
    label: "Rekening Langsung",
    desc: "Transfer zakat via rekening bank resmi BAZNAS",
    href: "#",
    eyebrow: "Cepat dan aman",
  },
  {
    icon: Store,
    label: "Kantor dan Minimarket",
    desc: "Bayar zakat di kantor BAZNAS atau gerai minimarket terdekat",
    href: "#",
    eyebrow: "Terdekat dari Anda",
  },
];

export function ShortcutSection() {
  return (
    <section className="bg-white py-8 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="rounded-[20px] border border-[#d0d5cc] bg-white p-4 shadow-[0_12px_36px_rgba(15,74,34,0.08)] lg:p-5">
          <div className="mb-4 flex flex-col gap-2 lg:flex-row lg:items-end lg:justify-between">
            <div className="max-w-2xl">
              <span className="inline-flex items-center rounded-full bg-[#e8eae5] px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-[0.18em] text-[#6b7367]">
                Shortcut pembayaran
              </span>
              <h2 className="mt-2 text-2xl font-black tracking-tight text-[#12351f] lg:text-3xl">
                Bayar Zakat, Infak, dan Sedekah
              </h2>
              <p className="mt-2 max-w-xl text-xs leading-relaxed text-slate-600 lg:text-sm">
                Pilih jalur pembayaran yang paling nyaman.
                Formulir online ditonjolkan sebagai aksi utama,
                sementara dua opsi lain tetap mudah diakses.
              </p>
            </div>
          </div>
          <div className="grid gap-4 lg:grid-cols-[1.15fr_0.85fr] lg:gap-5">
            {SHORTCUTS.slice(0, 1).map((item) => {
              const Icon = item.icon;
              const isInternal = item.href.startsWith("/");
              const ShortcutLink = isInternal ? Link : "a";
              const linkProps = isInternal
                ? { to: item.href }
                : { href: item.href };

              return (
                <ShortcutLink
                  key={item.label}
                  {...linkProps}
                  className="group relative overflow-hidden rounded-[20px] bg-gradient-to-br from-[#1a7a3a] via-[#166f33] to-[#0f4a22] p-4 text-white shadow-[0_12px_32px_rgba(15,74,34,0.14)] transition-transform duration-300 hover:-translate-y-0.5 lg:min-h-[200px] lg:p-5"
                >
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,255,255,0.12),transparent_35%)]" />
                  <div className="relative z-10 flex h-full flex-col justify-between gap-5">
                    <div>
                      <span className="inline-flex items-center rounded-full bg-white/15 px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-white/80">
                        {item.eyebrow}
                      </span>
                      <div className="mt-4 flex items-start gap-3">
                        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-white/20 text-white shadow-md transition-transform duration-300 group-hover:scale-105">
                          <Icon size={20} />
                        </div>
                        <div className="max-w-md">
                          <h3 className="text-lg font-black leading-tight lg:text-xl">
                            {item.label}
                          </h3>
                          <p className="mt-2 max-w-sm text-xs leading-relaxed text-white/75 lg:text-xs">
                            {item.desc}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="inline-flex items-center gap-1.5 self-start rounded-full bg-white px-3 py-1.5 text-xs font-semibold text-[#1a7a3a] shadow-sm">
                      Mulai
                      <ArrowRight size={14} />
                    </div>
                  </div>
                </ShortcutLink>
              );
            })}

            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-1">
              {SHORTCUTS.slice(1).map((item) => {
                const Icon = item.icon;
                const isInternal = item.href.startsWith("/");
                const ShortcutLink = isInternal ? Link : "a";
                const linkProps = isInternal
                  ? { to: item.href }
                  : { href: item.href };

                return (
                  <ShortcutLink
                    key={item.label}
                    {...linkProps}
                    className="group flex items-center gap-3 rounded-[16px] border border-[#d0d5cc] bg-white p-3 shadow-[0_8px_20px_rgba(15,74,34,0.06)] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_12px_28px_rgba(15,74,34,0.10)]"
                  >
                    <div className="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-lg bg-[#f0f2ee] text-[#1a7a3a] transition-transform duration-300 group-hover:scale-105">
                      <Icon size={20} />
                    </div>
                    <div className="min-w-0">
                      <div className="text-[10px] font-semibold uppercase tracking-[0.16em] text-[#6b7367]">
                        {item.eyebrow}
                      </div>
                      <div className="mt-0.5 text-sm font-bold text-slate-900">
                        {item.label}
                      </div>
                      <div className="mt-0.5 text-xs leading-relaxed text-slate-500">
                        {item.desc}
                      </div>
                    </div>
                  </ShortcutLink>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
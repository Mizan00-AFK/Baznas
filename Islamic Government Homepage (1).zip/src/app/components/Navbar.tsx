import { useState, useRef, useEffect } from "react";
import { Link } from "react-router";
import { ChevronDown } from "lucide-react";
import logo from "@/imports/Logo_BAZNAS_RI-Hijau-01.png";

const NAV_ITEMS = [
  { label: "Beranda", href: "/" },
  {
    label: "Profil",
    children: [
      { label: "Visi dan Misi", href: "#" },
      { label: "Pejabat Baznas", href: "#" },
      { label: "Profil Program", href: "#" },
      { label: "Penghargaan", href: "#" },
      { label: "Mitra Baznas", href: "#" },
    ],
  },
  {
    label: "Layanan",
    children: [
      {
        label: "Bayar ZIS",
        href: "#",
        sub: [
          {
            label: "Formulir",
            href: "/layanan/bayar-zis/formulir",
          },
          { label: "Rekening", href: "#" },
          { label: "Kantor dan Minimarket", href: "#" },
        ],
      },
      { label: "Register Penerima Zakat", href: "#" },
      { label: "Register Relawan", href: "#" },
      { label: "Register Label Taat Zakat", href: "#" },
    ],
  },
  {
    label: "Edukasi ZIS",
    children: [
      { label: "Zakat Fitrah", href: "#" },
      { label: "Zakat Mal", href: "#" },
      { label: "Infak", href: "#" },
      { label: "Sedekah", href: "#" },
      { label: "Fidyah", href: "#" },
    ],
  },
  {
    label: "Berita",
    children: [
      { label: "Berita Program", href: "#" },
      { label: "Siaran Pers", href: "#" },
      { label: "Artikel", href: "#" },
      { label: "Baznas TV", href: "#" },
      { label: "Newsletter", href: "#" },
    ],
  },
  { label: "PPID", href: "#" },
  {
    label: "Informasi Lainnya",
    children: [
      { label: "Laporan", href: "#" },
      { label: "Panduan Brand", href: "#" },
      { label: "Pustaka", href: "#" },
      { label: "Website Baznas Daerah", href: "#" },
      { label: "Jaringan Lembaga", href: "#" },
    ],
  },
];

type NavItem = (typeof NAV_ITEMS)[number];
type ChildItem = {
  label: string;
  href?: string;
  sub?: { label: string; href: string }[];
};

function DropdownMenu({
  items,
  hoveredSub,
  setHoveredSub,
}: {
  items: ChildItem[];
  hoveredSub: string | null;
  setHoveredSub: (v: string | null) => void;
}) {
  const timeoutRef = useRef<ReturnType<
    typeof setTimeout
  > | null>(null);

  const handleItemEnter = (label: string, hasSub: boolean) => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    setHoveredSub(hasSub ? label : null);
  };

  const handleItemLeave = () => {
    timeoutRef.current = setTimeout(() => {
      setHoveredSub(null);
    }, 100);
  };

  const handleSubEnter = () => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
  };

  useEffect(() => {
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, []);

  return (
    <div className="absolute top-full left-0 mt-0 bg-white shadow-xl border border-gray-100 min-w-[200px] z-50 rounded-b-lg">
      {items.map((child) => {
        const childHref = child.href || "#";
        const isChildInternal = childHref.startsWith("/");
        const ChildLink = isChildInternal ? Link : "a";
        const childLinkProps = isChildInternal
          ? { to: childHref }
          : { href: childHref };

        return (
          <div
            key={child.label}
            className="relative"
            onMouseEnter={() =>
              handleItemEnter(child.label, !!child.sub)
            }
            onMouseLeave={handleItemLeave}
          >
            <ChildLink
              {...childLinkProps}
              className="flex items-center justify-between px-4 py-2.5 text-sm text-gray-700 hover:bg-[#1a7a3a] hover:text-white transition-colors duration-150 whitespace-nowrap"
            >
              {child.label}
              {child.sub && (
                <ChevronDown
                  size={14}
                  className="-rotate-90 ml-2"
                />
              )}
            </ChildLink>
            {child.sub && hoveredSub === child.label && (
              <div
                className="absolute left-full top-0 ml-0 bg-white shadow-xl border border-gray-100 min-w-[220px] z-[60] rounded-r-lg"
                onMouseEnter={handleSubEnter}
                onMouseLeave={handleItemLeave}
              >
                {child.sub.map((sub) => {
                  const subHref = sub.href;
                  const isSubInternal = subHref.startsWith("/");
                  const SubLink = isSubInternal ? Link : "a";
                  const subLinkProps = isSubInternal
                    ? { to: subHref }
                    : { href: subHref };

                  return (
                    <SubLink
                      key={sub.label}
                      {...subLinkProps}
                      className="block px-4 py-2.5 text-sm text-gray-700 hover:bg-[#1a7a3a] hover:text-white transition-colors duration-150 whitespace-nowrap"
                    >
                      {sub.label}
                    </SubLink>
                  );
                })}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

export function Navbar() {
  const [openMenu, setOpenMenu] = useState<string | null>(null);
  const [hoveredSub, setHoveredSub] = useState<string | null>(
    null,
  );
  const [languageMenuOpen, setLanguageMenuOpen] =
    useState(false);
  const timeoutRef = useRef<ReturnType<
    typeof setTimeout
  > | null>(null);
  const languageMenuRef = useRef<HTMLDivElement | null>(null);
  const languageOptions = [
    { code: "ID", label: "Indonesia" },
    { code: "GB", label: "English" },
    { code: "SA", label: "العربية" },
  ];

  const handleMouseEnter = (label: string) => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    setOpenMenu(label);
    setHoveredSub(null);
  };

  const handleMouseLeave = () => {
    timeoutRef.current = setTimeout(() => {
      setOpenMenu(null);
      setHoveredSub(null);
    }, 120);
  };

  useEffect(
    () => () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    },
    [],
  );

  useEffect(() => {
    const handleOutsideClick = (event: MouseEvent) => {
      if (
        languageMenuRef.current &&
        !languageMenuRef.current.contains(event.target as Node)
      ) {
        setLanguageMenuOpen(false);
      }
    };

    document.addEventListener("mousedown", handleOutsideClick);
    return () =>
      document.removeEventListener(
        "mousedown",
        handleOutsideClick,
      );
  }, []);

  return (
    <>
      <nav className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex-shrink-0">
            <img
              src={logo}
              alt="BAZNAS"
              className="h-19 w-auto"
            />
          </Link>

          {/* Nav Links */}
          <div className="flex items-center gap-4">
            {NAV_ITEMS.map((item: NavItem) => {
              const href = "href" in item ? item.href : "#";
              const isInternal = href.startsWith("/");
              const NavLink = isInternal ? Link : "a";
              const linkProps = isInternal
                ? { to: href }
                : { href };

              return (
                <div
                  key={item.label}
                  className="relative"
                  onMouseEnter={() =>
                    "children" in item
                      ? handleMouseEnter(item.label)
                      : undefined
                  }
                  onMouseLeave={() =>
                    "children" in item
                      ? handleMouseLeave()
                      : undefined
                  }
                >
                  <NavLink
                    {...linkProps}
                    className={`flex items-center gap-1 text-sm font-medium transition-colors duration-150 whitespace-nowrap border-b-2 ${openMenu === item.label ? "text-[#1a7a3a] border-[#1a7a3a]" : "text-gray-700 hover:text-[#1a7a3a] border-transparent hover:border-[#1a7a3a]"} px-[12px] py-[20px]`}
                  >
                    {item.label}
                    {"children" in item && (
                      <ChevronDown
                        size={14}
                        className={`transition-transform duration-150 ${openMenu === item.label ? "rotate-180" : ""}`}
                      />
                    )}
                  </NavLink>
                  {"children" in item &&
                    openMenu === item.label && (
                      <div
                        onMouseEnter={() => {
                          if (timeoutRef.current)
                            clearTimeout(timeoutRef.current);
                        }}
                        onMouseLeave={handleMouseLeave}
                      >
                        <DropdownMenu
                          items={item.children as ChildItem[]}
                          hoveredSub={hoveredSub}
                          setHoveredSub={setHoveredSub}
                        />
                      </div>
                    )}
                </div>
              );
            })}
          </div>
        </div>
      </nav>

      <div
        ref={languageMenuRef}
        className="fixed top-24 left-6 z-[45]"
      >
        <button
          type="button"
          onClick={() => setLanguageMenuOpen((value) => !value)}
          className="flex min-w-[150px] items-center justify-between gap-3 rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-700 shadow-lg"
        >
          <span>ID Indonesia</span>
          <ChevronDown
            size={14}
            className={`text-gray-500 transition-transform duration-200 ${languageMenuOpen ? "rotate-180" : ""}`}
          />
        </button>

        {languageMenuOpen && (
          <div className="absolute top-full left-0 mt-2 overflow-hidden rounded-md border border-gray-300 bg-white shadow-xl">
            {languageOptions.map((option, index) => (
              <button
                key={option.code}
                type="button"
                className={`flex w-full items-center gap-3 px-3 py-2 text-left text-sm ${index === 0 ? "bg-[#1a73e8] text-white" : "text-gray-700 hover:bg-gray-50"}`}
              >
                <span className="w-7 text-xs font-semibold uppercase tracking-wide">
                  {option.code}
                </span>
                <span>{option.label}</span>
              </button>
            ))}
          </div>
        )}
      </div>
    </>
  );
}
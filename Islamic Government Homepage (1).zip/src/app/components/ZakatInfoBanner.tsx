import { ImageWithFallback } from "./figma/ImageWithFallback";

const STATS = [
  { label: "Muzakki Terdaftar", value: "4,2 Juta+" },
  { label: "Mustahik Terbantu", value: "2,8 Juta+" },
  { label: "Dana Terhimpun 2025", value: "Rp 4,07 T" },
  { label: "Provinsi Tercakup", value: "34 Provinsi" },
];

export function ZakatInfoBanner() {
  return (
    <section className="py-10 px-4 bg-gray-50">
      <div className="max-w-7xl mx-auto">
        <div
          className="relative rounded-2xl overflow-hidden shadow-xl"
          style={{ minHeight: "360px" }}
        >
          {/* Background image */}
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1630568419655-6dfb1ca30cfa?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHw0fHx6YWthdCUyMGNoYXJpdHklMjBJc2xhbWljJTIwZG9uYXRpb24lMjBJbmRvbmVzaWF8ZW58MXx8fHwxNzc5MTk2MzAyfDA&ixlib=rb-4.1.0&q=80&w=1080"
            alt="Penerima Zakat"
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#145c2c]/90 via-[#1a7a3a]/75 to-transparent" />

          {/* Content */}
          <div
            className="relative z-10 flex flex-col justify-between h-full p-8"
            style={{ minHeight: "360px" }}
          >
            <div>
              <span className="inline-block bg-white/20 backdrop-blur-sm text-white text-xs px-3 py-1 rounded-full mb-4">
                Dampak Nyata Zakat Anda
              </span>
              <h2
                className="text-white mb-3 max-w-md"
                style={{
                  fontSize: "1.75rem",
                  fontWeight: 700,
                  lineHeight: 1.3,
                }}
              >
                Bersama Kita Wujudkan Indonesia Tanpa Kemiskinan
              </h2>
              <p className="text-white/80 text-sm max-w-sm leading-relaxed">
                Setiap rupiah zakat yang Anda tunaikan
                berkontribusi nyata untuk mengentaskan
                kemiskinan dan meningkatkan kesejahteraan
                masyarakat Indonesia.
              </p>
            </div>

            {/* Stats */}
            <div className="mt-8">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {STATS.map((stat) => (
                  <div
                    key={stat.label}
                    className="bg-white/15 backdrop-blur-sm rounded-xl p-4 text-center"
                  >
                    <div
                      className="text-white"
                      style={{
                        fontSize: "1.4rem",
                        fontWeight: 700,
                      }}
                    >
                      {stat.value}
                    </div>
                    <div className="text-white/70 text-xs mt-1">
                      {stat.label}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
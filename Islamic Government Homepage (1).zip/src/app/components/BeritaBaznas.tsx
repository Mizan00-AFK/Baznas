import { ArrowRight, Calendar, Tag } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

const FEATURED_NEWS = {
  id: 1,
  image: 'https://images.unsplash.com/photo-1542562460-67f4b9aa9a25?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwzfHx6YWthdCUyMGNoYXJpdHklMjBJc2xhbWljJTIwZG9uYXRpb24lMjBJbmRvbmVzaWF8ZW58MXx8fHwxNzc5MTk2MzAyfDA&ixlib=rb-4.1.0&q=80&w=1080',
  category: 'Berita Program',
  date: '19 Mei 2026',
  title: 'BAZNAS Distribusikan Bantuan Pangan kepada 50.000 Keluarga Prasejahtera di 34 Provinsi',
  desc: 'Dalam rangka program penguatan ketahanan pangan nasional, BAZNAS secara serentak mendistribusikan paket bantuan pangan kepada puluhan ribu keluarga kurang mampu yang tersebar di seluruh provinsi di Indonesia. Program ini merupakan bagian dari komitmen BAZNAS dalam mewujudkan Indonesia Makmur melalui pendayagunaan zakat secara optimal.',
};

const NEWS_LIST = [
  {
    id: 2,
    image: 'https://images.unsplash.com/photo-1611087802810-046bb671e644?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400&q=80',
    category: 'Siaran Pers',
    date: '18 Mei 2026',
    title: 'BAZNAS dan Kemensos Perkuat Sinergi Program Pemberdayaan Masyarakat',
  },
  {
    id: 3,
    image: 'https://images.unsplash.com/photo-1715704170926-0ca943fce5a2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400&q=80',
    category: 'Artikel',
    date: '17 Mei 2026',
    title: 'Mengenal Lebih Dekat 8 Golongan Penerima Zakat (Mustahik) dalam Islam',
  },
  {
    id: 4,
    image: 'https://images.unsplash.com/photo-1629273229664-11fabc0becc0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400&q=80',
    category: 'Berita Program',
    date: '15 Mei 2026',
    title: 'Ribuan Anak Yatim Terima Santunan dari Program BAZNAS Peduli Anak',
  },
  {
    id: 5,
    image: 'https://images.unsplash.com/photo-1764738130382-cc7a8eaf26c7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400&q=80',
    category: 'Newsletter',
    date: '14 Mei 2026',
    title: 'Newsletter BAZNAS Edisi Mei 2026: Capaian dan Rencana Program Terbaru',
  },
  {
    id: 6,
    image: 'https://images.unsplash.com/photo-1761666507437-9fb5a6ef7b0a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400&q=80',
    category: 'Siaran Pers',
    date: '12 Mei 2026',
    title: 'BAZNAS Bantu Pemulihan Pascabencana di Wilayah Terdampak Banjir',
  },
];

const CATEGORY_COLORS: Record<string, string> = {
  'Berita Program': 'bg-emerald-100 text-emerald-700',
  'Siaran Pers': 'bg-blue-100 text-blue-700',
  'Artikel': 'bg-purple-100 text-purple-700',
  'Newsletter': 'bg-orange-100 text-orange-700',
};

export function BeritaBaznas() {
  return (
    <section className="py-10 px-4 bg-white">
      <div className="max-w-7xl mx-auto">
        {/* Section header */}
        <div className="flex items-end justify-between mb-6">
          <div>
            <span className="text-[#1a7a3a] text-xs uppercase tracking-widest" style={{ fontWeight: 600 }}>Terkini</span>
            <h2 className="text-gray-800 mt-1" style={{ fontSize: '1.75rem', fontWeight: 700 }}>Berita BAZNAS</h2>
          </div>
          <a
            href="#"
            className="hidden sm:flex items-center gap-1 text-[#1a7a3a] text-sm hover:underline"
            style={{ fontWeight: 500 }}
          >
            Lihat Semua <ArrowRight size={16} />
          </a>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          {/* Featured news - left, spans 3 cols */}
          <div className="lg:col-span-3 group cursor-pointer">
            <div className="rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-shadow duration-300 h-full flex flex-col">
              <div className="relative overflow-hidden" style={{ height: '280px' }}>
                <ImageWithFallback
                  src={FEATURED_NEWS.image}
                  alt={FEATURED_NEWS.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-4 left-4">
                  <span className={`text-xs px-2.5 py-1 rounded-full ${CATEGORY_COLORS[FEATURED_NEWS.category] ?? 'bg-gray-100 text-gray-700'}`} style={{ fontWeight: 500 }}>
                    {FEATURED_NEWS.category}
                  </span>
                </div>
              </div>
              <div className="p-5 flex-1 flex flex-col bg-white">
                <div className="flex items-center gap-1.5 text-gray-400 text-xs mb-3">
                  <Calendar size={13} />
                  {FEATURED_NEWS.date}
                </div>
                <h3 className="text-gray-800 mb-3 group-hover:text-[#1a7a3a] transition-colors" style={{ fontSize: '1.1rem', fontWeight: 700, lineHeight: 1.4 }}>
                  {FEATURED_NEWS.title}
                </h3>
                <p className="text-gray-500 text-sm leading-relaxed flex-1">{FEATURED_NEWS.desc}</p>
                <a href="#" className="inline-flex items-center gap-1 text-[#1a7a3a] text-sm mt-4 hover:gap-2 transition-all" style={{ fontWeight: 600 }}>
                  Baca Selengkapnya <ArrowRight size={15} />
                </a>
              </div>
            </div>
          </div>

          {/* News list - right, spans 2 cols */}
          <div className="lg:col-span-2 flex flex-col gap-3">
            {NEWS_LIST.map((news, idx) => (
              <a
                key={news.id}
                href="#"
                className={`flex gap-3 group hover:bg-gray-50 rounded-xl p-3 transition-colors duration-200 ${idx !== NEWS_LIST.length - 1 ? 'border-b border-gray-100' : ''}`}
              >
                <div className="flex-shrink-0 rounded-lg overflow-hidden" style={{ width: '72px', height: '64px' }}>
                  <ImageWithFallback
                    src={news.image}
                    alt={news.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 mb-1">
                    <Tag size={10} className="text-[#1a7a3a]" />
                    <span className="text-[#1a7a3a] text-xs" style={{ fontWeight: 500 }}>{news.category}</span>
                    <span className="text-gray-300">·</span>
                    <span className="text-gray-400 text-xs">{news.date}</span>
                  </div>
                  <p className="text-gray-700 text-sm group-hover:text-[#1a7a3a] transition-colors" style={{ fontWeight: 500, lineHeight: 1.4, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                    {news.title}
                  </p>
                </div>
              </a>
            ))}
            <a
              href="#"
              className="flex items-center justify-center gap-1 text-[#1a7a3a] text-sm border border-[#1a7a3a] rounded-xl py-2.5 mt-1 hover:bg-[#1a7a3a] hover:text-white transition-colors"
              style={{ fontWeight: 500 }}
            >
              Lihat Semua Berita <ArrowRight size={15} />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

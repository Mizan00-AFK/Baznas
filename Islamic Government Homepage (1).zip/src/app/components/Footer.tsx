import {
  Facebook,
  Instagram,
  Mail,
  MapPin,
  Phone,
  Youtube,
  X,
  YoutubeIcon,
} from "lucide-react";
import logo from "@/imports/Logo_BAZNAS_RI-Hijau-01.png";

const profileLinks = [
  "Visi & Misi",
  "Pejabat Baznas",
  "Profil Program",
  "Penghargaan",
  "Mitra Baznas",
];
const serviceLinks = [
  "Formulir ZIS",
  "Register Penerima",
  "Register Relawan",
  "Register Label Taat Zakat",
];
const educationLinks = [
  "Zakat Fitrah",
  "Zakat Mal",
  "Infak",
  "Sedekah",
  "Fidyah",
];

export function Footer() {
  return (
    <footer className="bg-[#f6f8fb] text-[#1f2a44] border-t border-slate-200 mt-8">
      <div className="max-w-7xl mx-auto px-4 py-10 sm:py-12">
        <div className="grid gap-10 lg:grid-cols-[1.1fr_0.9fr_0.9fr_0.9fr_1.1fr]">
          <div className="space-y-5">
            <div className="flex items-start gap-3">
              <img
                src={logo}
                alt="BAZNAS"
                className="h-20 w-auto object-contain"
              />
            </div>
            <p className="max-w-xs text-sm leading-6 text-slate-600">
              Badan Amil Zakat Nasional adalah lembaga resmi
              pengelola zakat, infak, dan sedekah di Indonesia
              untuk membantu masyarakat yang membutuhkan.
            </p>
          </div>

          <div>
            <h3 className="mb-5 text-base font-semibold text-[#1f2a44]">
              Profil BAZNAS
            </h3>
            <ul className="space-y-3 text-sm text-slate-600">
              {profileLinks.map((item) => (
                <li key={item}>
                  <a
                    href="#"
                    className="transition hover:text-[#1a7a3a]"
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="mb-5 text-base font-semibold text-[#1f2a44]">
              Layanan
            </h3>
            <ul className="space-y-3 text-sm text-slate-600">
              {serviceLinks.map((item) => (
                <li key={item}>
                  <a
                    href="#"
                    className="transition hover:text-[#1a7a3a]"
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="mb-5 text-base font-semibold text-[#1f2a44]">
              Edukasi ZIS
            </h3>
            <ul className="space-y-3 text-sm text-slate-600">
              {educationLinks.map((item) => (
                <li key={item}>
                  <a
                    href="#"
                    className="transition hover:text-[#1a7a3a]"
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-6">
            <div>
              <h3 className="mb-4 text-base font-semibold text-[#1f2a44]">
                Media Sosial
              </h3>
              <div className="flex items-center gap-4 text-[#1f2a44]">
                <a
                  href="#"
                  aria-label="Facebook"
                  className="transition hover:text-[#1a7a3a]"
                >
                  <Facebook size={19} />
                </a>
                <a
                  href="#"
                  aria-label="Instagram"
                  className="transition hover:text-[#1a7a3a]"
                >
                  <Instagram size={19} />
                </a>
                <a
                  href="#"
                  aria-label="X"
                  className="transition hover:text-[#1a7a3a]"
                >
                  <X size={19} />
                </a>
                <a
                  href="#"
                  aria-label="YouTube"
                  className="transition hover:text-[#1a7a3a]"
                >
                  <YoutubeIcon size={19} />
                </a>
              </div>
            </div>

            <div>
              <h3 className="mb-4 text-base font-semibold text-[#1f2a44]">
                Kontak
              </h3>
              <ul className="space-y-3 text-sm text-slate-600">
                <li className="flex gap-3">
                  <MapPin
                    className="mt-0.5 shrink-0 text-[#1a7a3a]"
                    size={18}
                  />
                  <span>
                    Jl. Matraman Raya No.134, Jakarta Timur
                    13150
                  </span>
                </li>
                <li className="flex gap-3">
                  <Mail
                    className="mt-0.5 shrink-0 text-[#1a7a3a]"
                    size={18}
                  />
                  <span>humas@baznas.go.id</span>
                </li>
                <li className="flex gap-3">
                  <Phone
                    className="mt-0.5 shrink-0 text-[#1a7a3a]"
                    size={18}
                  />
                  <span>(021) 739 1936</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="mt-10 border-t border-slate-200 pt-5 text-center text-xs text-slate-500">
          © 2026 Badan Amil Zakat Nasional | All Rights
          Reserved
        </div>
      </div>
    </footer>
  );
}
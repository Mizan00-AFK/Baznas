import { useState } from "react";
import { Breadcrumb } from "../components/Breadcrumb";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

export function FormulirBayarZIS() {
  const [activeTab, setActiveTab] = useState<
    "formulir" | "kalkulator"
  >("formulir");
  const [kalkulatorTab, setKalkulatorTab] = useState<
    "maal" | "penghasilan"
  >("maal");

  // Form states
  const [jenisDana, setJenisDana] = useState("zakat");
  const [subJenis, setSubJenis] = useState("zakat-maal");
  const [nominal, setNominal] = useState("");
  const [nama, setNama] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [gender, setGender] = useState("bapak");

  // Kalkulator Maal states
  const [nilaiEmas, setNilaiEmas] = useState("");
  const [uangTunai, setUangTunai] = useState("");
  const [kendaraan, setKendaraan] = useState("");
  const [hutang, setHutang] = useState("");

  // Kalkulator Penghasilan states
  const [gaji, setGaji] = useState("");
  const [emas2, setEmas2] = useState("");
  const [tunai2, setTunai2] = useState("");
  const [kendaraan2, setKendaraan2] = useState("");
  const [hutang2, setHutang2] = useState("");

  const breadcrumbItems = [
    { label: "Beranda", href: "/" },
    { label: "Layanan", href: "#" },
    { label: "Bayar ZIS", href: "#" },
    { label: "Formulir" },
  ];

  // Live calculator for Zakat Maal
  const calculateMaal = () => {
    const total =
      (parseFloat(nilaiEmas) || 0) +
      (parseFloat(uangTunai) || 0) +
      (parseFloat(kendaraan) || 0) -
      (parseFloat(hutang) || 0);

    const nisab = 85 * 1000000;
    if (total >= nisab) {
      return total * 0.025;
    }
    return 0;
  };

  // Live calculator for Zakat Penghasilan
  const calculatePenghasilan = () => {
    const total =
      (parseFloat(gaji) || 0) +
      (parseFloat(emas2) || 0) +
      (parseFloat(tunai2) || 0) +
      (parseFloat(kendaraan2) || 0) -
      (parseFloat(hutang2) || 0);

    const nisab = 85 * 1000000;
    if (total >= nisab) {
      return total * 0.025;
    }
    return 0;
  };

  const hasilMaal = calculateMaal();
  const hasilPenghasilan = calculatePenghasilan();

  const handleResetMaal = () => {
    setNilaiEmas("");
    setUangTunai("");
    setKendaraan("");
    setHutang("");
  };

  const handleResetPenghasilan = () => {
    setGaji("");
    setEmas2("");
    setTunai2("");
    setKendaraan2("");
    setHutang2("");
  };

  return (
    <>
      <Breadcrumb items={breadcrumbItems} />

      <div className="max-w-6xl mx-auto px-6 py-8">
        <div className="mb-8">
          <div className="w-full h-48 bg-gray-200 rounded-lg overflow-hidden mb-4">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1532629345422-7515f3d16bb6?w=800&h=300&fit=crop"
              alt="Baznas Hero"
              className="w-full h-full object-cover"
            />
          </div>
          <h1 className="text-center text-2xl font-bold mb-2">
            TUNAIKAN ZAKAT, INFAK, DAN SEDEKAH
            <br />
            ANDA DENGAN{" "}
            <span className="text-[#1a7a3a]">
              AMAN DAN MUDAH
            </span>
          </h1>
        </div>

        <div className="flex gap-4 mb-6">
          <button
            onClick={() => setActiveTab("formulir")}
            className={`flex-1 py-4 text-sm font-medium transition-colors border-b-2 ${
              activeTab === "formulir"
                ? "text-[#1a7a3a] border-[#1a7a3a] bg-white"
                : "text-gray-500 border-transparent hover:text-gray-700 bg-gray-50"
            }`}
          >
            Isi Formulir
          </button>
          <button
            onClick={() => setActiveTab("kalkulator")}
            className={`flex-1 py-4 text-sm font-medium transition-colors border-b-2 ${
              activeTab === "kalkulator"
                ? "text-[#1a7a3a] border-[#1a7a3a] bg-white"
                : "text-gray-500 border-transparent hover:text-gray-700 bg-gray-50"
            }`}
          >
            Kalkulator
          </button>
        </div>

        {activeTab === "formulir" ? (
          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-900 mb-2">
                Pilih Jenis Dana
              </label>
              <select
                value={jenisDana}
                onChange={(e) => setJenisDana(e.target.value)}
                className="w-full border border-gray-300 rounded-md px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a7a3a] focus:border-transparent"
              >
                <option value="zakat">Zakat</option>
                <option value="infak">Infak</option>
                <option value="sedekah">Sedekah</option>
                <option value="fidyah">Fidyah</option>
                <option value="kurban">Kurban</option>
                <option value="dam-haji">Dam Haji</option>
              </select>
            </div>

            {jenisDana === "zakat" && (
              <div className="mb-6">
                <select
                  value={subJenis}
                  onChange={(e) => setSubJenis(e.target.value)}
                  className="w-full border border-gray-300 rounded-md px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a7a3a] focus:border-transparent"
                >
                  <option value="zakat-maal">Zakat Maal</option>
                  <option value="zakat-penghasilan">
                    Zakat Penghasilan
                  </option>
                </select>
              </div>
            )}

            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-900 mb-2">
                Masukkan Nominal:
              </label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 text-sm">
                  Rp
                </span>
                <input
                  type="text"
                  value={nominal}
                  onChange={(e) => setNominal(e.target.value)}
                  className="w-full border border-gray-300 rounded-md pl-12 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a7a3a] focus:border-transparent"
                  placeholder="0"
                />
              </div>
            </div>

            <div className="border-t pt-6 mt-6">
              <label className="block text-sm font-medium text-gray-900 mb-4">
                Silahkan lengkapi data di bawah ini:
              </label>

              <div className="mb-4">
                <input
                  type="text"
                  value={nama}
                  onChange={(e) => setNama(e.target.value)}
                  className="w-full border border-gray-300 rounded-md px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a7a3a] focus:border-transparent"
                  placeholder="Fakhri Iqbaradasasd"
                />
              </div>

              <div className="mb-4">
                <div className="flex gap-6">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="gender"
                      value="bapak"
                      checked={gender === "bapak"}
                      onChange={(e) =>
                        setGender(e.target.value)
                      }
                      className="w-4 h-4 text-[#1a7a3a]"
                    />
                    <span className="text-sm text-gray-700">
                      Bapak
                    </span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="gender"
                      value="ibu"
                      checked={gender === "ibu"}
                      onChange={(e) =>
                        setGender(e.target.value)
                      }
                      className="w-4 h-4 text-[#1a7a3a]"
                    />
                    <span className="text-sm text-gray-700">
                      Ibu
                    </span>
                  </label>
                </div>
              </div>

              <div className="mb-4">
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full border border-gray-300 rounded-md px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a7a3a] focus:border-transparent"
                  placeholder="08228651712"
                />
              </div>

              <div className="mb-6">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full border border-gray-300 rounded-md px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a7a3a] focus:border-transparent"
                  placeholder="fakhri@gmail.com"
                />
              </div>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-md p-4 mb-6 flex gap-3">
              <div className="flex-shrink-0">
                <div className="w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs font-bold">
                  i
                </div>
              </div>
              <p className="text-sm text-gray-700">
                Informasi yang Anda masukkan ke dalam formulir
                akan dibagikan ke BAZNAS untuk tujuan zakat dan
                diproses oleh BAZNAS sesuai dengan kebijakan
                privasi BAZNAS.
              </p>
            </div>

            <button className="w-full bg-[#1a7a3a] text-white font-medium py-3 rounded-md hover:bg-[#156830] transition-colors">
              Pilih Pembayaran
            </button>
          </div>
        ) : (
          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="flex gap-3 mb-6">
              <button
                onClick={() => setKalkulatorTab("maal")}
                className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
                  kalkulatorTab === "maal"
                    ? "bg-[#1a7a3a] text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                Zakat Maal
              </button>
              <button
                onClick={() => setKalkulatorTab("penghasilan")}
                className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
                  kalkulatorTab === "penghasilan"
                    ? "bg-[#1a7a3a] text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                Zakat Penghasilan
              </button>
            </div>

            {kalkulatorTab === "maal" && (
              <div>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nilai emas, perak, dan/atau permata
                  </label>
                  <input
                    type="number"
                    value={nilaiEmas}
                    onChange={(e) =>
                      setNilaiEmas(e.target.value)
                    }
                    className="w-full border border-gray-300 rounded-md px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a7a3a] focus:border-transparent"
                    placeholder="0"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Uang tunai, tabungan, deposito
                  </label>
                  <input
                    type="number"
                    value={uangTunai}
                    onChange={(e) =>
                      setUangTunai(e.target.value)
                    }
                    className="w-full border border-gray-300 rounded-md px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a7a3a] focus:border-transparent"
                    placeholder="0"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Kendaraan, rumah, aset lain
                  </label>
                  <input
                    type="number"
                    value={kendaraan}
                    onChange={(e) =>
                      setKendaraan(e.target.value)
                    }
                    className="w-full border border-gray-300 rounded-md px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a7a3a] focus:border-transparent"
                    placeholder="0"
                  />
                </div>

                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Jumlah hutang/cicilan (optional)
                  </label>
                  <input
                    type="number"
                    value={hutang}
                    onChange={(e) => setHutang(e.target.value)}
                    className="w-full border border-gray-300 rounded-md px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a7a3a] focus:border-transparent"
                    placeholder="0"
                  />
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-md p-4 mb-6 flex gap-3">
                  <div className="flex-shrink-0">
                    <div className="w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs font-bold">
                      i
                    </div>
                  </div>
                  <p className="text-sm text-gray-700">
                    Informasi yang Anda masukkan ke dalam
                    kalkulator zakat akan dibagikan ke BAZNAS
                    untuk tujuan perhitungan zakat dan diproses
                    oleh BAZNAS sesuai dengan kebijakan privasi
                    BAZNAS.
                  </p>
                </div>

                <div className="bg-green-50 border border-green-200 rounded-md p-4 mb-6">
                  <p className="text-sm text-gray-600 mb-1">
                    Besar
                  </p>
                  <p className="text-3xl font-bold text-[#1a7a3a]">
                    Rp {hasilMaal.toLocaleString("id-ID")}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <button
                    onClick={handleResetMaal}
                    className="border border-gray-300 text-gray-700 font-medium py-3 rounded-md hover:bg-gray-50 transition-colors"
                  >
                    Reset
                  </button>
                  <button className="bg-[#1a7a3a] text-white font-medium py-3 rounded-md hover:bg-[#156830] transition-colors">
                    Lanjut
                  </button>
                </div>
              </div>
            )}

            {kalkulatorTab === "penghasilan" && (
              <div>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nilai gaji/penghasilan
                  </label>
                  <input
                    type="number"
                    value={gaji}
                    onChange={(e) => setGaji(e.target.value)}
                    className="w-full border border-gray-300 rounded-md px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a7a3a] focus:border-transparent"
                    placeholder="0"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nilai emas, perak, dan/atau permata
                  </label>
                  <input
                    type="number"
                    value={emas2}
                    onChange={(e) => setEmas2(e.target.value)}
                    className="w-full border border-gray-300 rounded-md px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a7a3a] focus:border-transparent"
                    placeholder="0"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Uang tunai, tabungan, deposito
                  </label>
                  <input
                    type="number"
                    value={tunai2}
                    onChange={(e) => setTunai2(e.target.value)}
                    className="w-full border border-gray-300 rounded-md px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a7a3a] focus:border-transparent"
                    placeholder="0"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Kendaraan, rumah, aset lain
                  </label>
                  <input
                    type="number"
                    value={kendaraan2}
                    onChange={(e) =>
                      setKendaraan2(e.target.value)
                    }
                    className="w-full border border-gray-300 rounded-md px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a7a3a] focus:border-transparent"
                    placeholder="0"
                  />
                </div>

                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Jumlah hutang/cicilan (optional)
                  </label>
                  <input
                    type="number"
                    value={hutang2}
                    onChange={(e) => setHutang2(e.target.value)}
                    className="w-full border border-gray-300 rounded-md px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#1a7a3a] focus:border-transparent"
                    placeholder="0"
                  />
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-md p-4 mb-6 flex gap-3">
                  <div className="flex-shrink-0">
                    <div className="w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs font-bold">
                      i
                    </div>
                  </div>
                  <p className="text-sm text-gray-700">
                    Informasi yang Anda masukkan ke dalam
                    kalkulator zakat akan dibagikan ke BAZNAS
                    untuk tujuan perhitungan zakat dan diproses
                    oleh BAZNAS sesuai dengan kebijakan privasi
                    BAZNAS.
                  </p>
                </div>

                <div className="bg-green-50 border border-green-200 rounded-md p-4 mb-6">
                  <p className="text-sm text-gray-600 mb-1">
                    Besar
                  </p>
                  <p className="text-3xl font-bold text-[#1a7a3a]">
                    Rp{" "}
                    {hasilPenghasilan.toLocaleString("id-ID")}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <button
                    onClick={handleResetPenghasilan}
                    className="border border-gray-300 text-gray-700 font-medium py-3 rounded-md hover:bg-gray-50 transition-colors"
                  >
                    Reset
                  </button>
                  <button className="bg-[#1a7a3a] text-white font-medium py-3 rounded-md hover:bg-[#156830] transition-colors">
                    Lanjut
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </>
  );
}
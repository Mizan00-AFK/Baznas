import { HeroCarousel } from '../components/HeroCarousel';
import { ShortcutSection } from '../components/ShortcutSection';
import { ZakatInfoBanner } from '../components/ZakatInfoBanner';
import { BeritaBaznas } from '../components/BeritaBaznas';

export function HomePage() {
  return (
    <>
      <HeroCarousel />
      <ShortcutSection />
      <ZakatInfoBanner />
      <BeritaBaznas />
    </>
  );
}
